<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Log out</name>
   <tag></tag>
   <elementGuidId>6c55a859-c773-49d2-9569-158a41ce4f57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/header/div/div/div/div[2]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.jss21 > a.MuiButtonBase-root.MuiButton-root.MuiButton-contained.jss10.MuiButton-containedSizeSmall.MuiButton-sizeSmall.MuiButton-disableElevation > span.MuiButton-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>88590fb4-a656-4481-b0ac-7bb633d0ff98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButton-label</value>
      <webElementGuid>00b85c39-3535-4df8-92c1-503ff06507be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Log out</value>
      <webElementGuid>000f9729-47c6-45a9-b144-cf06827e6b92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/header[@class=&quot;MuiPaper-root MuiAppBar-root MuiAppBar-positionFixed MuiAppBar-colorPrimary jss1 mui-fixed MuiPaper-elevation4&quot;]/div[@class=&quot;MuiToolbar-root MuiToolbar-regular jss3&quot;]/div[@class=&quot;jss17&quot;]/div[@class=&quot;MuiBox-root jss19&quot;]/div[@class=&quot;MuiBox-root jss21&quot;]/a[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-contained jss10 MuiButton-containedSizeSmall MuiButton-sizeSmall MuiButton-disableElevation&quot;]/span[@class=&quot;MuiButton-label&quot;]</value>
      <webElementGuid>b12c5eaf-813e-4f46-8146-89a0119feede</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/header/div/div/div/div[2]/a/span</value>
      <webElementGuid>2ca2a332-ad57-4528-a2bb-4ada2b292441</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::span[2]</value>
      <webElementGuid>fa3d9c05-172e-4ab0-a8dc-e5b5f3a7be03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[1]/following::span[4]</value>
      <webElementGuid>2ce13277-1b5d-4d2f-8d7b-6458c02d2645</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[2]/preceding::span[5]</value>
      <webElementGuid>3c23836d-d48b-4429-abb8-2a4f324c86f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[2]/preceding::span[5]</value>
      <webElementGuid>4370150a-7cb7-4f0b-8737-80ceba92403f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log out']/parent::*</value>
      <webElementGuid>de00e155-795c-46a0-a7d2-724b71814c41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/span</value>
      <webElementGuid>466bedfa-2a7f-474f-949e-8cd836a717d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Log out' or . = 'Log out')]</value>
      <webElementGuid>75db7138-b609-4238-8f66-35c0e45526f6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
