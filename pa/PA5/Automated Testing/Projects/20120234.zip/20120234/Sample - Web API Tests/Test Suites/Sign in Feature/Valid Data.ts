<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Valid Data</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f5a53592-209e-4f58-9998-1b42464ca9aa</testSuiteGuid>
   <testCaseLink>
      <guid>507ab940-c504-4666-ba04-4a44237b64ab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign In Feature/Sign in With Valid Data</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>6ca99ab0-b4e8-4fb1-aabd-8e598a793e58</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Sign In Sample Data Input/Valid User Account</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>6ca99ab0-b4e8-4fb1-aabd-8e598a793e58</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>800c6b2c-f0ee-4ee0-a615-133365027986</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>6ca99ab0-b4e8-4fb1-aabd-8e598a793e58</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>a6ffb178-0f09-4847-8ed9-861c71bd6274</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
