<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign in</name>
   <tag></tag>
   <elementGuidId>57d49034-175e-4268-bd0f-4f1f57342291</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButtonGroup-grouped.MuiButtonGroup-groupedHorizontal.MuiButtonGroup-groupedContained.MuiButtonGroup-groupedContainedHorizontal.MuiButtonGroup-groupedContained.jss10.MuiButton-containedPrimary.MuiButton-disableElevation > span.MuiButton-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/header/div/div/div/div[4]/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2c4ec108-9ecd-4843-9255-dbe9b6e8a3eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButton-label</value>
      <webElementGuid>5b1f2de8-ebe0-4162-afc0-3aa8d24a4810</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign in</value>
      <webElementGuid>468d719d-442d-44b6-b698-60b4a09539c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/header[@class=&quot;MuiPaper-root MuiAppBar-root MuiAppBar-positionFixed MuiAppBar-colorPrimary jss1 mui-fixed MuiPaper-elevation4&quot;]/div[@class=&quot;MuiToolbar-root MuiToolbar-regular jss3&quot;]/div[@class=&quot;jss17&quot;]/div[@class=&quot;MuiBox-root jss19&quot;]/div[@class=&quot;MuiButtonGroup-root MuiButtonGroup-disableElevation MuiButtonGroup-contained&quot;]/a[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-contained MuiButtonGroup-grouped MuiButtonGroup-groupedHorizontal MuiButtonGroup-groupedContained MuiButtonGroup-groupedContainedHorizontal MuiButtonGroup-groupedContained jss10 MuiButton-containedPrimary MuiButton-disableElevation&quot;]/span[@class=&quot;MuiButton-label&quot;]</value>
      <webElementGuid>d67c3b2d-f056-4e61-a0ff-b4e5e5c8e8fe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/header/div/div/div/div[4]/a/span</value>
      <webElementGuid>0562ab0c-60da-4319-aa6d-b52099252391</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[2]/following::span[7]</value>
      <webElementGuid>eccf5a49-3ffd-464a-9b1d-40e78e56b796</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cart'])[1]/following::span[7]</value>
      <webElementGuid>d111d4be-1b89-45f3-b0ad-a3c4eaecfe3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up'])[1]/preceding::span[4]</value>
      <webElementGuid>79626a80-b570-4d7c-a8e7-2ac0a957c4ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shopping Cart'])[1]/preceding::span[8]</value>
      <webElementGuid>b06d3f0b-a9f3-4a0b-b540-8c160fecacee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign in']/parent::*</value>
      <webElementGuid>351f0200-1372-4c19-915f-f14bb2c18c52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a/span</value>
      <webElementGuid>9b645d82-49d6-4636-97bf-490b5f56e355</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign in' or . = 'Sign in')]</value>
      <webElementGuid>4ce89259-f0cb-4c05-a268-93977a1c9009</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
