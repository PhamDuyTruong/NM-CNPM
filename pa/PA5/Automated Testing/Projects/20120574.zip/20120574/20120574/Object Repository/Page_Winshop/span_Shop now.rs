<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Shop now</name>
   <tag></tag>
   <elementGuidId>aaab7e17-06bf-4610-988d-4dbaa1a184cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div/div/div[3]/a/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a > button.MuiButtonBase-root.MuiButton-root.MuiButton-text.primary-btn.red > span.MuiButton-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8330258a-70c8-475b-ac39-9988819446a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButton-label</value>
      <webElementGuid>39ac8f1d-ff2c-432a-9ee8-9c36a39425e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shop now</value>
      <webElementGuid>722cf9dc-f8d1-43ef-b78a-5d59258d92f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[1]/section[@class=&quot;home-banners&quot;]/div[@class=&quot;slides&quot;]/div[@class=&quot;home-banner&quot;]/div[@class=&quot;MuiContainer-root container-ui MuiContainer-maxWidthLg&quot;]/div[@class=&quot;home-banner__container&quot;]/div[3]/a[1]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text primary-btn red&quot;]/span[@class=&quot;MuiButton-label&quot;]</value>
      <webElementGuid>50165b04-ac48-40d8-aa72-07a383118735</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div/div/div[3]/a/button/span</value>
      <webElementGuid>007a736a-fc5c-46a4-a33a-da5655c467d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Checkout'])[1]/following::span[2]</value>
      <webElementGuid>0d5f6949-51a7-4884-aeeb-b413b6f7818b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy more'])[1]/following::span[5]</value>
      <webElementGuid>9a30edac-c591-49b8-96aa-da9d6cfebef7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ecommerce-simplified'])[1]/preceding::span[4]</value>
      <webElementGuid>ec0df468-7f9a-4826-b026-fae1fc552eef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shop now']/parent::*</value>
      <webElementGuid>32233973-9aeb-47d5-873d-a5de861e6a81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/button/span</value>
      <webElementGuid>197abd41-a07e-42b4-986e-24a396196951</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Shop now' or . = 'Shop now')]</value>
      <webElementGuid>f35d8a70-4326-45a5-9d20-8217880b43db</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
