<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Add product</name>
   <tag></tag>
   <elementGuidId>78427506-61df-475f-8608-f16b9ac8752a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div[2]/div[2]/a/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ProductPage-addButton > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a859ae19-3d0b-461a-b206-fa6581bb0762</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add product</value>
      <webElementGuid>fc8c987f-bb1b-4f2b-afb6-32807e9865da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;adminpage&quot;]/div[@class=&quot;headerAndContent&quot;]/div[@class=&quot;ProductsPage-container&quot;]/a[1]/div[@class=&quot;ProductPage-addButton&quot;]/span[1]</value>
      <webElementGuid>4909a455-e1ec-4383-8ce5-4e4214696f80</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[2]/a/div/span</value>
      <webElementGuid>c01fe237-a8e5-4597-b112-610239754727</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::span[1]</value>
      <webElementGuid>865bc307-b8aa-45dd-9640-1b5f479a5ed7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::span[1]</value>
      <webElementGuid>7e169084-2b52-472d-b091-6553bf998799</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$15'])[1]/preceding::span[1]</value>
      <webElementGuid>59db26cb-d0d4-44e6-b445-56f5940baf4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GOING ROGUE'])[1]/preceding::span[2]</value>
      <webElementGuid>ec245295-a71d-471e-8276-5287681f8dca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add product']/parent::*</value>
      <webElementGuid>79dfc072-1da7-46b4-816c-2f229fdf9e90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/span</value>
      <webElementGuid>f4c06d6d-1098-438d-bfa9-1bfa3cd74849</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Add product' or . = 'Add product')]</value>
      <webElementGuid>07bf072b-543c-4d9a-8732-fe5d8fdccf6b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
