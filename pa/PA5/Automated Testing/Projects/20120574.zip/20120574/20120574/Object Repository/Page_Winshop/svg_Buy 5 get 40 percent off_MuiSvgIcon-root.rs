<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Buy 5 get 40 percent off_MuiSvgIcon-root</name>
   <tag></tag>
   <elementGuidId>5064350e-401d-42a9-a679-b51757aec5cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 5 get 40 percent off'])[1]/following::*[name()='svg'][2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MuiButtonBase-root.MuiButton-root.MuiButton-text.detail-content__btn-dec.btn-circle > span.MuiButton-label > svg.MuiSvgIcon-root</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>7409d474-a32c-4d93-9667-d752c7772223</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root</value>
      <webElementGuid>23de245b-d00e-49ae-aac0-29b24c245105</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>b3c747c2-355b-4d4f-b268-7d931abd8928</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>0717827e-e764-4a44-9e12-656282f79155</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>3394f61d-f35f-4d9f-874e-2977e4c80e25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;detail&quot;]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg&quot;]/section[@class=&quot;detail__container&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-6&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-6&quot;]/div[@class=&quot;detail-content&quot;]/div[@class=&quot;detail-content__btns&quot;]/div[@class=&quot;detail-content__btn-handle&quot;]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text detail-content__btn-dec btn-circle&quot;]/span[@class=&quot;MuiButton-label&quot;]/svg[@class=&quot;MuiSvgIcon-root&quot;]</value>
      <webElementGuid>3430de46-baaf-4700-b1dd-4c3bfc8aae87</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 5 get 40 percent off'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>1abee5f4-4a25-4190-9f56-1c432a610592</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 3 get 25 percent off'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>06aca124-dc37-4a4f-9fee-b2cd3f833027</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>d6002d10-308d-4c43-a422-e3610b9e53b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free global shipping on all orders'])[1]/preceding::*[name()='svg'][4]</value>
      <webElementGuid>f6e29c49-38de-4e4a-a006-496681ae9a91</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
