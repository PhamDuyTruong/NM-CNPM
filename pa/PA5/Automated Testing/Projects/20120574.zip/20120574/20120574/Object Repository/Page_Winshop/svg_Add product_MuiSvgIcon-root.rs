<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Add product_MuiSvgIcon-root</name>
   <tag></tag>
   <elementGuidId>f82a2cb1-82e3-42f5-b799-54fc193167c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Add product'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.ProductBox-editIcon > svg.MuiSvgIcon-root</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>af0d3b5b-d4fa-4964-829b-b2b683662d0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root</value>
      <webElementGuid>8bc9fe95-f69e-4597-a107-deaca37f3985</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>948ec580-f74c-4607-8f7c-79a782b6111c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>ca8f7b1d-14d8-484d-b31e-238aacd75c55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>0f2e1c93-0824-432f-9866-4a7ca1ee652f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;adminpage&quot;]/div[@class=&quot;headerAndContent&quot;]/div[@class=&quot;ProductsPage-container&quot;]/div[@class=&quot;ProductsPage&quot;]/div[@class=&quot;ProductBox-container&quot;]/div[@class=&quot;ProductBox-img-container&quot;]/a[@class=&quot;ProductBox-editIcon&quot;]/svg[@class=&quot;MuiSvgIcon-root&quot;]</value>
      <webElementGuid>4b644429-d378-4632-90c2-17a65ebd62a2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add product'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>16dbfc34-3ad2-4525-bb2b-8386df7fc0c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>2d61964f-1cdf-4101-abd8-aaecb3a6e933</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$16'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>0b14e195-487b-4569-8b5d-128d15b623c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAIRY TAL'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>2fdd175d-e964-4553-98ec-78ac9e4a5e65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$12'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>e36afbeb-c5da-471f-87c5-f5bb3b528478</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interesting Facts For Curious Minds'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>6343b1da-6d20-4fe2-87dd-46e7b3a0e29f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
