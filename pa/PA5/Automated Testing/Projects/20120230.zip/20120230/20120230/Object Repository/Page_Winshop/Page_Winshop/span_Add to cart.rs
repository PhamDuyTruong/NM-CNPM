<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Add to cart</name>
   <tag></tag>
   <elementGuidId>5b23c3d1-2518-4b87-b2a5-6aa566dc79f0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/section/div/div[2]/div/div[4]/div[2]/button/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MuiButtonBase-root.MuiButton-root.MuiButton-text.primary-btn.red > span.MuiButton-label > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7976998e-92eb-4f1f-852b-0a6a550bca62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to cart</value>
      <webElementGuid>6b869ef1-2f0e-4eb8-abbb-8f2412e68e55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;detail&quot;]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg&quot;]/section[@class=&quot;detail__container&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-6&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-6&quot;]/div[@class=&quot;detail-content&quot;]/div[@class=&quot;detail-content__btns&quot;]/div[@class=&quot;detail-content__add&quot;]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text primary-btn red&quot;]/span[@class=&quot;MuiButton-label&quot;]/span[1]</value>
      <webElementGuid>b02eb9d3-2b09-4e22-a10b-685616414ce5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/section/div/div[2]/div/div[4]/div[2]/button/span/span</value>
      <webElementGuid>23533a8f-384d-45bc-9551-53b29f85c6b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 5 get 40 percent off'])[1]/following::span[7]</value>
      <webElementGuid>f58224f9-643a-4d57-ac87-581c146da713</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buy 3 get 25 percent off'])[1]/following::span[8]</value>
      <webElementGuid>c06d8bde-f11d-4a56-9919-e3872297a146</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free global shipping on all orders'])[1]/preceding::span[6]</value>
      <webElementGuid>276d74b2-d5b8-4bd3-97b9-7ddea7b76fc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order before noon for same day dispatch'])[1]/preceding::span[8]</value>
      <webElementGuid>a54c7c38-5fcd-473b-bc59-53f6f4b26509</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to cart']/parent::*</value>
      <webElementGuid>b44d22f4-faee-42ca-99d2-9fdea1525d35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span/span</value>
      <webElementGuid>89700b63-fd57-4da6-8d9e-c0ee0486219e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Add to cart' or . = 'Add to cart')]</value>
      <webElementGuid>e986a5f5-55c3-4c0c-b7a6-721b45348ea1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
